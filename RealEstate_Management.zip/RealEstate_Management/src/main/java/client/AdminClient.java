/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/JerseyClient.java to edit this template
 */
package client;

import entity.Propertydetails;
import entity.Propertyimages;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Jersey REST client generated for REST resource:AdminResource [admin]<br>
 * USAGE:
 * <pre>
 *        AdminClient client = new AdminClient();
 *        Object response = client.XXX(...);
 *        // do whatever with response
 *        client.close();
 * </pre>
 *
 * @author DELL
 */
public class AdminClient {

    private WebTarget webTarget;
    private Client client;
    private static final String BASE_URI = "http://localhost:8080/RealEstate_Management/resources";

    public AdminClient() {
        client = javax.ws.rs.client.ClientBuilder.newClient();
        webTarget = client.target(BASE_URI).path("admin");
    }
    //===============ALL GET METHODS CLIENT==================
    public <T> T getAllStates(GenericType<T> responseType) throws ClientErrorException {
        WebTarget resource = webTarget;
        resource = resource.path("states");
        return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
    }

    public <T> T getAllCities(GenericType<T> responseType) throws ClientErrorException {
        WebTarget resource = webTarget;
        resource = resource.path("cities");
        return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
    }

    public <T> T getAllAreas(GenericType<T> responseType) throws ClientErrorException {
        WebTarget resource = webTarget;
        resource = resource.path("areas");
        return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
    }

    public <T> T getAllTypes(GenericType<T> responseType) throws ClientErrorException {
        WebTarget resource = webTarget;
        resource = resource.path("types");
        return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
    }

    public <T> T getAllStatus(GenericType<T> responseType) throws ClientErrorException {
        WebTarget resource = webTarget;
        resource = resource.path("status");
        return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
    }
    
    public <T> T getAllRoles(GenericType<T> responseType) throws ClientErrorException {
            WebTarget resource = webTarget;
            resource = resource.path("roles");
            return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
    }

    public <T> T getAllProperties(GenericType<T> responseType) throws ClientErrorException {
        WebTarget resource = webTarget;
        resource = resource.path("properties");
        return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
    }
    public <T> T getAllUsers(GenericType<T> responseType) throws ClientErrorException {
            WebTarget resource = webTarget;
            resource = resource.path("users");
            return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
    }

    public <T> T getAllFeedbacks(GenericType<T> responseType) throws ClientErrorException {
            WebTarget resource = webTarget;
            resource = resource.path("feedbacks");
            return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
    }
    
    //=============ALL STATE CLIENT METHODS========================
    public void addStates(Object requestEntity, String stateName) throws ClientErrorException {
        webTarget.path(java.text.MessageFormat.format("addstates/{0}", new Object[]{stateName})).request(javax.ws.rs.core.MediaType.APPLICATION_JSON).post(javax.ws.rs.client.Entity.entity(requestEntity, javax.ws.rs.core.MediaType.APPLICATION_JSON));
    }

//    public Response deleteState(int stateid) throws ClientErrorException {
//            return webTarget.path("deletestate/{stateid}")
//                .resolveTemplate("id", stateid)
//                .request()
//                .delete();
//        }
    public void deleteState(String stateid) throws ClientErrorException {
        webTarget.path(java.text.MessageFormat.format("deletestate/{0}", new Object[]{stateid})).request().delete();
    }

    //=============ALL CITY CLIENT METHODS=================
    public Response addCity(String cityName, Integer stateId) throws ClientErrorException {
        return webTarget
                .path(java.text.MessageFormat.format("addcity/{0}/{1}",
                 new Object[]{cityName, stateId}))
                .request(MediaType.APPLICATION_JSON)
                .post(null, Response.class);
    }

    public void deleteCity(String cityid) throws ClientErrorException {
            webTarget.path(java.text.MessageFormat.format("deletecity/{0}", new Object[]{cityid})).request().delete();
    }
    
    //=============ALL AREA CLIENT METHODS===========================
    public Response addArea(String areaName, Integer cityId) throws ClientErrorException {
        return webTarget
                .path(java.text.MessageFormat.format("addarea/{0}/{1}",
                        new Object[]{areaName, cityId}))
                .request(MediaType.APPLICATION_JSON)
                .post(null, Response.class);
    }
    public void deleteArea(String areaid) throws ClientErrorException {
            webTarget.path(java.text.MessageFormat.format("deletearea/{0}", 
                    new Object[]{areaid})).request().delete();
    }

    //====================ALL PROPERTYDETAILS CLIENT METHODS======================
    public void addProperty(String typeId, String description, String price, String address, String yearBuilt, String statusId, String stateId, String cityId, String areaId) throws ClientErrorException {
        webTarget.path(java.text.MessageFormat.format("addproperty/{0}/{1}/{2}/{3}/{4}/{5}/{6}/{7}/{8}",
                new Object[]{typeId, description, price, address, yearBuilt, statusId, stateId, cityId, areaId}))
                .request().post(null);
    }
    
    public void deleteProperty(String propertyId) throws ClientErrorException {
            webTarget.path(java.text.MessageFormat.format("deleteproperty/{0}", 
                    new Object[]{propertyId})).request().delete();
    }
    
    //===================ALL USERMASTER CLIENT METHODS===========================
    public void addUser(String userName, String contactNo, String address, String email, String password, String roleId) throws ClientErrorException {
            webTarget
                    .path(java.text.MessageFormat.format("adduser/{0}/{1}/{2}/{3}/{4}/{5}",
                     new Object[]{userName, contactNo, address, email, password, roleId}))
                    .request().post(null);
    }

    public void updateUser(String userId, String userName, String contactNo, String address, String email, String password, String roleId) throws ClientErrorException {
            webTarget
                    .path(java.text.MessageFormat.format("updateuser/{0}/{1}/{2}/{3}/{4}/{5}/{6}",
                    new Object[]{userId, userName, contactNo, address, email, password, roleId}))
                    .request().post(null);
    }
    
//
//    public List<Propertyimages> getImagesByPropertyId(Integer propertyId) {
//        Client client = ClientBuilder.newClient();
//        return client.target(BASE_URI + "/admin/image/{0}" + propertyId).request(MediaType.APPLICATION_JSON)
//                .get(new GenericType<List<Propertyimages>>() {
//                });
//    }
    public void addImage(Propertyimages image) {
        client.target(BASE_URI+"addimage")
              .request(MediaType.APPLICATION_JSON)
              .post(Entity.json(image));
    }

    public List<Propertyimages> getAllImages() {
        return client.target(BASE_URI+"images")
                     .request(MediaType.APPLICATION_JSON)
                     .get(new GenericType<List<Propertyimages>>() {});
    }
     
    public void close() {
        client.close();
    }

}
