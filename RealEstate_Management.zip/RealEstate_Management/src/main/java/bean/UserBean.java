/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package bean;

import client.UserClient;
import entity.Propertydetails;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.Collection;
import javax.annotation.PostConstruct;
import javax.ws.rs.core.GenericType;

/**
 *
 * @author DELL
 */
@Named(value = "userBean")
@SessionScoped
public class UserBean implements Serializable {
    
    private String description;
    private Integer propertyId;
    private Integer userId;

    UserClient userclient;
    Collection<Propertydetails> propertyList;
    
    GenericType<Collection<Propertydetails>> propertyGenericType = new  GenericType<Collection<Propertydetails>>(){};
   public UserBean() {
    }
    
    @PostConstruct
    public void init(){
        try{
            userclient = new UserClient();
            propertyList = userclient.getAllProperties(propertyGenericType);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public String addFeedback(){
        userclient.addFeedback(description, String.valueOf(propertyId),String.valueOf(userId));
        return "Feedback.xhtml";
    }

    public Collection<Propertydetails> getPropertyList() {
        return propertyList;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(Integer propertyId) {
        this.propertyId = propertyId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    
    
    
}
