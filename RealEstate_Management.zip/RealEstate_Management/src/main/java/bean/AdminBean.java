/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package bean;

import client.AdminClient;
import entity.Areamaster;
import entity.Citymaster;
import entity.Feedbackdetails;
import entity.Propertydetails;
import entity.Propertyimages;
import entity.Propertystatus;
import entity.Propertytype;
import entity.Rolemaster;
import entity.Statemaster;
import entity.Usermaster;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.Collection;
import javax.annotation.PostConstruct;
import javax.servlet.http.Part;
import javax.ws.rs.ClientErrorException;
import javax.ws.rs.core.GenericType;

/**
 *
 * @author DELL
 */
@Named(value = "adminBean")
@SessionScoped
public class AdminBean implements Serializable {
    
    private Propertyimages image = new Propertyimages();
    private AdminClient adminclient;
    
   private Part uploadedFile;
    private String imagedescription;
//    private Integer propertyId;
    
    private String stateName;
    private String cityName;
    private Integer stateid;
    private String areaName;
    private Integer cityid;
    private Integer areaid;
    
    
    
    private Integer typeid;
    private String description;
    private Double price;
    private String address;
    private Integer year;
    private Integer statusid;
    private Integer propertyId;
    
    private Integer userId;
    private String userName;
    private long contactNo;
    private String email;
    private String password;
    private Integer roleId;
    
    private Propertydetails property;
    private Usermaster current;
    private Rolemaster role;
    
    Collection<Statemaster> stateList;
    Collection<Citymaster> cityList;
    Collection<Areamaster> areaList;
    Collection<Propertytype> typeList;
    Collection<Propertystatus> statusList;
    Collection<Propertydetails> propertyList;
    Collection<Usermaster> userList;
    Collection<Rolemaster> roleList;
    Collection<Feedbackdetails> feedbackList;
    
    
    private final GenericType<Collection<Statemaster>> stateGenericType = new GenericType<Collection<Statemaster>>() {
    };
    private final GenericType<Collection<Citymaster>> cityGenericType = new GenericType<Collection<Citymaster>>() {
    };
    private final GenericType<Collection<Areamaster>> areaGenericType = new GenericType<Collection<Areamaster>>() {
    };
    private final GenericType<Collection<Propertytype>> typeGenericType = new GenericType<Collection<Propertytype>>() {
    };
    private final GenericType<Collection<Propertystatus>> statusGenericType = new GenericType<Collection<Propertystatus>>() {
    };
    private final GenericType<Collection<Propertydetails>> propGenericType = new GenericType<Collection<Propertydetails>>(){
    };
    private final GenericType<Collection<Usermaster>> userGenericType = new GenericType<Collection<Usermaster>>(){
    };
    private final GenericType<Collection<Rolemaster>> roleGenericType = new GenericType<Collection<Rolemaster>>(){
    };
    private final GenericType<Collection<Feedbackdetails>> feedbackGenericType = new GenericType<Collection<Feedbackdetails>>(){
    };
    
    public AdminBean() {
    }
    
    @PostConstruct
    public void init() {
        try {
            adminclient = new AdminClient();
            stateList = adminclient.getAllStates(stateGenericType);
            cityList = adminclient.getAllCities(cityGenericType);
            areaList = adminclient.getAllAreas(areaGenericType);
            typeList = adminclient.getAllTypes(typeGenericType);
            statusList = adminclient.getAllStatus(statusGenericType);
            propertyList = adminclient.getAllProperties(propGenericType);
            userList = adminclient.getAllUsers(userGenericType);
            roleList = adminclient.getAllRoles(roleGenericType);
            feedbackList = adminclient.getAllFeedbacks(feedbackGenericType);
            property = new Propertydetails();
            clearForm();
            
        } catch (ClientErrorException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
        
    private void clearForm() {
        property = new Propertydetails();
    }
    
    //========ALL STATEMASTER METHODS===============
    public void addState() {
        try {
            Statemaster newState = new Statemaster();
            newState.setStateName(stateName);
            adminclient.addStates(newState, stateName);
            stateList = adminclient.getAllStates(stateGenericType);
            stateName = "";
        } catch (ClientErrorException e) {
            
        }
    }
    
    public String deleteState() {
        adminclient.deleteState(String.valueOf(stateid));
        return "state.xhtml";
    }   

    //============ALL CITYMASTER METHODS===================
    public void addCity() {
        try {
            adminclient.addCity(cityName, stateid);
            
            cityList = adminclient.getAllCities(cityGenericType);
            
            cityName = "";
            stateid = null;
//            String.valueOf(stateid) = null;
        } catch (ClientErrorException e) {
            e.printStackTrace();
        }
    }
    
    public String deleteCity() {
        adminclient.deleteCity(String.valueOf(cityid));
        System.out.println("City deleted");
        return "city.xhtml";
    } 
    
    //============ALL AREAMASTER METHODS=====================
    public void addArea() {
        try {
            adminclient.addArea(areaName, cityid);
            
            areaList = adminclient.getAllAreas(areaGenericType);
            
            areaName = "";
            cityid = null;
        } catch (ClientErrorException e) {
            e.printStackTrace();
        }
    }
    public String deleteArea() {
        adminclient.deleteArea(String.valueOf(areaid));
        System.out.println("Area deleted");
        return "area.xhtml";
    }
    
    public void addImage() {
        if (uploadedFile != null) {
            try {
                // Save the uploaded file to a directory
                String fileName = getFileName(uploadedFile);
                String uploadPath = "C:/Users/DELL/Payara_Server/glassfish/domains/domain1/config/uploads/" + fileName; // Change this path accordingly
                
                saveFile(uploadedFile.getInputStream(), uploadPath);

                // Create Propertyimages object
                Propertyimages image = new Propertyimages();
                image.setImageUrl(uploadPath);
                image.setDescription(description);

                Propertydetails property = new Propertydetails();
                property.setPropertyId(propertyId);
                image.setPropertyId(property);

                adminclient.addImage(image);
                System.out.println("Image add in client");
                clearFields();
                

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveFile(InputStream input, String filePath) throws IOException {
        File file = new File(filePath);
    File directory = file.getParentFile(); // Get the directory part of the file path

    if (!directory.exists()) {
        directory.mkdirs(); // Create the directory if it doesn't exist
    }

    // Save the file
    try (FileOutputStream out = new FileOutputStream(file)) {
        int read;
        byte[] bytes = new byte[1024];
        while ((read = input.read(bytes)) != -1) {
            out.write(bytes, 0, read);
        }
    }
    }

    private String getFileName(Part part) {
        for (String content : part.getHeader("content-disposition").split(";")) {
            if (content.trim().startsWith("filename")) {
                return content.substring(content.indexOf("=") + 2, content.length() - 1);
            }
        }
        return "Image added";
    }

    private void clearFields() {
        uploadedFile = null;
        description = null;
        propertyId = null;
    }
    
    //==========ALL USERMASTER METHODS=================
    public String addUser()
    {
        System.out.println("In Bean");
        adminclient.addUser(userName, String.valueOf(contactNo),address,email,password, String.valueOf(roleId));
        return "Login.xhtml";
    }
    
    public String updateUser()
    {
        userName= current.getUserName();
        userId = current.getUserId();
        contactNo = current.getContactNo();
        address = current.getAddress();
        email = current.getEmail();
        password = current.getPassword();
        roleId = current.getRoleId().getRoleId();
        
        adminclient.updateUser(String.valueOf(userId), userName, String.valueOf(contactNo), address, email, password, String.valueOf(roleId));
        System.out.println("In cdi bean user updated");
        return "ShowUsers.xhtml";
    }
    
    public String  redirectToEditUser()
  {
      return "EditUser.xhtml";
  }
    
    //==========ALL PROPERTYMASTER METHODS================
    public String addProperty(){
        System.out.println("In Bean");
        adminclient.addProperty(String.valueOf(typeid), description, String.valueOf(price), address,
                String.valueOf(year), String.valueOf(statusid),
                String.valueOf(stateid), String.valueOf(cityid), String.valueOf(areaid));
        return "properties.xhtml";
    }
    
    public String deleteProperty() {
        adminclient.deleteProperty(String.valueOf(propertyId));
        System.out.println("Property deleted");
        return "";
    }
    
    //==========ALL COLLECTION GETTER METHODS====================
    public Collection<Statemaster> getStateList() {
        return stateList;
    }
    
    public Collection<Citymaster> getCityList() {
        return cityList;
    }
    
    public Collection<Areamaster> getAreaList() {
        return areaList;
    }

    public Collection<Propertytype> getTypeList() {
        return typeList;
    }

    public Collection<Propertystatus> getStatusList() {
        return statusList;
    }
    
    public Collection<Propertydetails> getPropertyList() {
        return propertyList;
    }

    public Collection<Usermaster> getUserList() {
        return userList;
    }

    public Collection<Rolemaster> getRoleList() {
        return roleList;
    }

    public Collection<Feedbackdetails> getFeedbackList() {
        return feedbackList;
    }

    //=========ALL GETTER SETTER METHODS===============
    public String getStateName() {
        return stateName;
    }
    
    public void setStateName(String stateName) {
        this.stateName = stateName;
    }
    
    public String getCityName() {
        return cityName;
    }
    
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
    
    public Integer getStateid() {
        return stateid;
    }
    
    public void setStateid(Integer stateid) {
        this.stateid = stateid;
    }
    
    public String getAreaName() {
        return areaName;
    }
    
    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }
    
    public Integer getCityid() {
        return cityid;
    }
    
    public void setCityid(Integer cityid) {
        this.cityid = cityid;
    }
    
    public Integer getAreaid() {
        return areaid;
    }
    
    public void setAreaid(Integer areaid) {
        this.areaid = areaid;
    }
    
    public Part getUploadedFile() {
        return uploadedFile;
    }
    
    public void setUploadedFile(Part uploadedFile) {
        this.uploadedFile = uploadedFile;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Integer getPropertyId() {
        return propertyId;
    }
    
    public void setPropertyId(Integer propertyId) {
        this.propertyId = propertyId;
    }
    
    public Propertyimages getImage() {
        return image;
    }
    
    public void setImage(Propertyimages image) {
        this.image = image;
    }
    
    public Propertydetails getProperty() {
        return property;
    }
    
    public void setProperty(Propertydetails property) {
        this.property = property;
    }
    
    public Double getPrice() {
        return price;
    }
    
    public void setPrice(Double price) {
        this.price = price;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public Integer getYear() {
        return year;
    }
    
    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getTypeid() {
        return typeid;
    }

    public void setTypeid(Integer typeid) {
        this.typeid = typeid;
    }

    public Integer getStatusid() {
        return statusid;
    }

    public void setStatusid(Integer statusid) {
        this.statusid = statusid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public long getContactNo() {
        return contactNo;
    }

    public void setContactNo(long contactNo) {
        this.contactNo = contactNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }
    
     public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Usermaster getCurrent() {
        return current;
    }

    public void setCurrent(Usermaster current) {
        this.current = current;
    }
    
     public Rolemaster getRole() {
        return role;
    }

    public void setRole(Rolemaster role) {
        this.role = role;
    }
    
    public String getImagedescription() {
        return imagedescription;
    }

    public void setImagedescription(String imagedescription) {
        this.imagedescription = imagedescription;
    }
    
//    public void uploadImage() {
//        if (uploadedFile != null) {
//            try {
//                // Define the directory for saving the uploaded file
//                String uploadDir = "/c:uploads/";
//                File fileDir = new File(uploadDir);
//                if (!fileDir.exists()) {
//                    fileDir.mkdirs(); // Create the directory if it doesn't exist
//                }
//                String fileName = uploadedFile.getSubmittedFileName();
//                String filePath = uploadDir + fileName;
//
//                // Save the file to the server
//                uploadedFile.write(filePath);
//
//                // Create Propertyimages entity
//                Propertyimages image = new Propertyimages();
//                image.setImageUrl(filePath);
//                image.setDescription(description);
//                image.setPropertyId(property);
//
//                // Send image metadata to the backend
//                adminclient.addImage(image);
//                
//                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Image uploaded successfully!"));
//            } catch (IOException e) {
//                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Image upload failed", e.getMessage()));
//            }
//        }
//    }
//    

    

   

    

}
