/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionLocal.java to edit this template
 */
package ejb;

import entity.Propertydetails;
import java.util.Collection;
import javax.ejb.Local;

/**
 *
 * @author DELL
 */
@Local
public interface UserEJBLocal {
    
    public Collection<Propertydetails> getAllProperties();
    
    void addFeedback(String description, Integer propertyId, Integer userId);
}
