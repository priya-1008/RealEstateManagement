/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.Areamaster;
import entity.Citymaster;
import entity.Feedbackdetails;
import entity.Propertydetails;
import entity.Propertyimages;
import entity.Propertystatus;
import entity.Propertytype;
import entity.Rolemaster;
import entity.Statemaster;
import entity.Usermaster;
import java.util.Collection;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author DELL
 */
@Stateless
public class AdminEJB implements AdminEJBLocal {
    
    @PersistenceContext(unitName = "my_per_unit")
    private EntityManager em;

    //==========All State Methods===============
    @Override
    public Collection<Statemaster> getAllStates() {
        return em.createNamedQuery("Statemaster.findAll",Statemaster.class).getResultList();
    }

    @Override
    public void addState(String stateName) {
        Statemaster state = new Statemaster();
        state.setStateName(stateName);
        em.persist(state);
    }
    
    @Override
    public void deleteState(Integer stateId) {
        Statemaster state = em.find(Statemaster.class, stateId);
        if (state != null) {
            em.remove(state);
        }
    }
    
    @Override
    public void updateState(Integer stateId, String stateName) {
        
    }
    
    @Override
    public Statemaster getStateById(Integer stateId) {
        try {
            return em.createNamedQuery("StateMaster.findByStateId", Statemaster.class)
                    .setParameter("assetId", stateId)
                    .getSingleResult();
        } catch (javax.persistence.NoResultException e) {
            return null; // or you could throw an exception or handle it as needed
        }
    }
    
    //==================All City Methods====================
    
    @Override
    public Collection<Citymaster> getAllCities() {
        return em.createNamedQuery("Citymaster.findAll", Citymaster.class).getResultList();
    }

    @Override
    public void addCity(String cityName, Integer stateId) {
        Statemaster stateid = (Statemaster) em.find(Statemaster.class, stateId);
        Citymaster city = new Citymaster();
        city.setCityName(cityName);
        city.setStateId(stateid);
        em.persist(city);
    }
    
    @Override
    public void deleteCity(Integer cityId) {
        Citymaster city = em.find(Citymaster.class, cityId);
        if (city != null) {
            em.remove(city);
        }
        System.out.println("In Delete City EJB");
    }

    //===============All Area Methods=====================
    
    @Override
    public Collection<Areamaster> getAllAreas() {
        return em.createNamedQuery("Areamaster.findAll", Areamaster.class).getResultList();
    }

    @Override
    public void addArea(String areaName, Integer cityId) {
        Citymaster cityid = (Citymaster) em.find(Citymaster.class, cityId);
        Areamaster area = new Areamaster();
        area.setAreaName(areaName);
        area.setCityId(cityid);
        em.persist(area);
    }
    
    @Override
    public void deleteArea(Integer areaId) {
        Areamaster area = em.find(Areamaster.class, areaId);
        if (area != null) {
            em.remove(area);
        }
        System.out.println("In Delete Area EJB");
    }
    
    //==================ALL PROPERTY TYPE METHODS==============
    @Override
    public Collection<Propertytype> getAlltypes() {
        return em.createNamedQuery("Propertytype.findAll",Propertytype.class).getResultList();
    }
    
    //==================ALL PROPERTY STATUS METHODS==============
    @Override
    public Collection<Propertystatus> getAllStatus() {
        return em.createNamedQuery("Propertystatus.findAll",Propertystatus.class).getResultList();
    }

    @Override
    public Collection<Rolemaster> getAllRoles() {
        return em.createNamedQuery("Rolemaster.findAll",Rolemaster.class).getResultList();
    }
    
    //=================All Propertyimages Methods========================
     @Override
    public void addImage(Propertyimages image) {
        em.persist(image);
        System.out.println("Image add in EJB");
    }

    @Override
    public List<Propertyimages> getAllImages() {
        return em.createNamedQuery("Propertyimages.findAll", Propertyimages.class).getResultList();
    }
    
    //===============ALL PROPERTYDETAILS METHODS====================
    @Override
    public Collection<Propertydetails> getAllProperties() {
        return em.createNamedQuery("Propertydetails.findAll",Propertydetails.class).getResultList();
    }

    @Override
    public void addProperty(Integer typeId, String description, Double price, String address, Integer yearBuilt, Integer statusId, Integer stateId, Integer cityId, Integer areaId) {
       
        Propertytype typeid = (Propertytype) em.find(Propertytype.class, typeId);
        Collection<Propertydetails> property1 = typeid.getPropertydetailsCollection();
        Propertystatus statusid = (Propertystatus) em.find(Propertystatus.class, statusId);
        Collection<Propertydetails> property2 = statusid.getPropertydetailsCollection();
        Statemaster stateid = (Statemaster) em.find(Statemaster.class, stateId);
        Collection<Propertydetails> property3 = stateid.getPropertydetailsCollection();
        Citymaster cityid = (Citymaster) em.find(Citymaster.class, cityId);
        Collection<Propertydetails> property4 = cityid.getPropertydetailsCollection();
        Areamaster areaid = (Areamaster) em.find(Areamaster.class, areaId);
        Collection<Propertydetails> property5 = areaid.getPropertydetailsCollection();
       
        Propertydetails property = new Propertydetails();
        property.setTypeId(typeid);
        property.setDescription(description);
        property.setPropertyPrice(price);
        property.setAddress(address);
        property.setYearBuilt(yearBuilt);
        property.setStatusId(statusid);
        property.setStateId(stateid);
        property.setCityId(cityid);
        property.setAreaId(areaid);
        property1.add(property);
        property2.add(property);
        property3.add(property);
        property4.add(property);
        property5.add(property);
        typeid.setPropertydetailsCollection(property1);
        statusid.setPropertydetailsCollection(property2);
        stateid.setPropertydetailsCollection(property3);
        cityid.setPropertydetailsCollection(property4);
        areaid.setPropertydetailsCollection(property5);
        em.persist(property);
        em.merge(typeid);
        em.merge(statusid);
        em.merge(stateid);
        em.merge(cityid);
        em.merge(areaid);
        System.out.println("In EJB");
    }
    
    @Override
    public void deleteProperty(Integer propertyId) {
        Propertydetails prop = em.find(Propertydetails.class,propertyId);
        if(prop != null){
            em.remove(prop);
        }
        System.out.println("In EJB property deleted");
    }

    //=============ALL USERMASTER METHODS=================
    @Override
    public Collection<Usermaster> getAllUsers() {
        return em.createNamedQuery("Usermaster.findAll", Usermaster.class).getResultList();
    }

    @Override
    public void addUser(String userName, long contactNo, String address, String email, String password, Integer roleId) {
        Rolemaster role = (Rolemaster) em.find(Rolemaster.class, roleId);
        Collection<Usermaster> users = role.getUsermasterCollection();
        Usermaster user = new Usermaster();
        user.setUserName(userName);
        user.setContactNo(contactNo);
        user.setAddress(address);
        user.setEmail(email);
        user.setPassword(password);
        user.setRoleId(role);
        users.add(user);
        role.setUsermasterCollection(users);
        em.persist(user);
        em.merge(role);
        System.out.println("In EJB");
    } 

    @Override
    public void updateUser(Integer userId, String userName, long contactNo, String address, String email, String password, Integer roleId) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Rolemaster role = (Rolemaster) em.find(Rolemaster.class, roleId);
        Collection<Usermaster> users = role.getUsermasterCollection();
        Usermaster user = (Usermaster) em.find(Usermaster.class,userId);
        if(users.contains(user)){
            users.remove(user);
        }
        user.setUserName(userName);
        user.setContactNo(contactNo);
        user.setAddress(address);
        user.setEmail(email);
        user.setPassword(password);
        user.setRoleId(role);
        users.add(user);
        role.setUsermasterCollection(users);
        em.merge(user);
        em.merge(role);
        System.out.println("In EJB user updated");
    }   

    //==========ALL FEEDBACKDETAILS METHODS==============
    @Override
    public Collection<Feedbackdetails> getAllFeedbacks() {
        return em.createNamedQuery("Feedbackdetails.findAll",Feedbackdetails.class).getResultList();
    }

}
