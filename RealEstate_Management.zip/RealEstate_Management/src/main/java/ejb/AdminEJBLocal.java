package ejb;

import entity.Areamaster;
import entity.Citymaster;
import entity.Feedbackdetails;
import entity.Propertydetails;
import entity.Propertyimages;
import entity.Propertystatus;
import entity.Propertytype;
import entity.Rolemaster;
import entity.Statemaster;
import entity.Usermaster;
import java.util.Collection;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author DELL
 */
@Local
public interface AdminEJBLocal {
    
    //=========All State Methods===================
    public Collection<Statemaster> getAllStates();
    void addState(String stateName);
    void deleteState(Integer stateId);
    void updateState(Integer stateId, String stateName);
    Statemaster getStateById(Integer stateId);
    
    //=========All City Methods=================
    public Collection<Citymaster> getAllCities();
    void addCity(String cityName, Integer stateId);
    void deleteCity(Integer cityId);
    
    //================All Area Methods================
    public Collection<Areamaster> getAllAreas();
    void addArea(String areaName, Integer cityId);
    void deleteArea(Integer areaId);
    
    //================All Property Type Methods================
    public Collection<Propertytype> getAlltypes();
    
    //===========All Property Status Methods============
    public Collection<Propertystatus> getAllStatus();
    
    //=============ALL ROLEMASTER METHODS==================
    public Collection<Rolemaster> getAllRoles();
    
   //==============All Property Images Methods=================
    void addImage(Propertyimages image);
    List<Propertyimages> getAllImages();
    
    //============ALL PROPERTYDETAILS METHODS====================
    public Collection<Propertydetails> getAllProperties();
    void addProperty(Integer typeId, String description, Double price, String address, Integer yearBuilt, Integer statusId, Integer stateId,Integer cityId, Integer areaId);
    void deleteProperty(Integer propertyId);
    
    //===========ALL USERMASTER METHODS===================
    public Collection<Usermaster> getAllUsers();
    void addUser(String userName, long contactNo, String address, String email, String password, Integer roleId);
    void updateUser(Integer userId, String userName, long contactNo, String address, String email, String password, Integer roleId);
//    Usermaster getUserById(Integer userId);
    
    //=========ALL FEEDBACKDETAILS METHODS==================
    public Collection<Feedbackdetails> getAllFeedbacks();
}
