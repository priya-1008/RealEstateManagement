/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.Feedbackdetails;
import entity.Propertydetails;
import entity.Usermaster;
import java.util.Collection;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author DELL
 */
@Stateless
public class UserEJB implements UserEJBLocal {
    
    @PersistenceContext(unitName = "my_per_unit")
    private EntityManager em;

    @Override
    public Collection<Propertydetails> getAllProperties() {
        return em.createNamedQuery("Propertydetails.findAll",Propertydetails.class).getResultList();
    }

    @Override
    public void addFeedback(String description, Integer propertyId, Integer userId) {
        Propertydetails p = (Propertydetails) em.find(Propertydetails.class, propertyId);
        Collection<Feedbackdetails> feedbacks = p.getFeedbackdetailsCollection();
        Usermaster u = (Usermaster) em.find(Usermaster.class, userId);
        Collection<Feedbackdetails> feedbacks1 = u.getFeedbackdetailsCollection();
        
        Feedbackdetails feedback = new Feedbackdetails();
        feedback.setDescription(description);
        feedback.setPropertyId(p);
        feedback.setUserId(u);
        
        feedbacks.add(feedback);
        feedbacks1.add(feedback);
        
        p.setFeedbackdetailsCollection(feedbacks);
        u.setFeedbackdetailsCollection(feedbacks1);
        
        em.persist(feedback);
        em.merge(u);
        em.merge(p);
        System.out.println("In User EJB");
    }
    
    
    
}
