/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Collection;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author DELL
 */
@Entity
@Table(name = "propertydetails")
@NamedQueries({
    @NamedQuery(name = "Propertydetails.findAll", query = "SELECT p FROM Propertydetails p"),
    @NamedQuery(name = "Propertydetails.findByPropertyId", query = "SELECT p FROM Propertydetails p WHERE p.propertyId = :propertyId"),
    @NamedQuery(name = "Propertydetails.findByDescription", query = "SELECT p FROM Propertydetails p WHERE p.description = :description"),
    @NamedQuery(name = "Propertydetails.findByPropertyPrice", query = "SELECT p FROM Propertydetails p WHERE p.propertyPrice = :propertyPrice"),
    @NamedQuery(name = "Propertydetails.findByAddress", query = "SELECT p FROM Propertydetails p WHERE p.address = :address"),
    @NamedQuery(name = "Propertydetails.findByYearBuilt", query = "SELECT p FROM Propertydetails p WHERE p.yearBuilt = :yearBuilt")})
public class Propertydetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "propertyId")
    private Integer propertyId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "description")
    private String description;
    @Basic(optional = false)
    @NotNull
    @Column(name = "propertyPrice")
    private double propertyPrice;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "address")
    private String address;
    @Basic(optional = false)
    @NotNull
    @Column(name = "yearBuilt")
    private int yearBuilt;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "propertyId")
    private Collection<Propertyimages> propertyimagesCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "propertyId")
    private Collection<Transactiondetails> transactiondetailsCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "propertyId")
    private Collection<Feedbackdetails> feedbackdetailsCollection;
    @JoinColumn(name = "areaId", referencedColumnName = "areaId")
    @ManyToOne(optional = false)
    private Areamaster areaId;
    @JoinColumn(name = "cityId", referencedColumnName = "cityId")
    @ManyToOne(optional = false)
    private Citymaster cityId;
    @JoinColumn(name = "stateId", referencedColumnName = "stateId")
    @ManyToOne(optional = false)
    private Statemaster stateId;
    @JoinColumn(name = "typeId", referencedColumnName = "typeId")
    @ManyToOne(optional = false)
    private Propertytype typeId;
    @JoinColumn(name = "statusId", referencedColumnName = "statusId")
    @ManyToOne(optional = false)
    private Propertystatus statusId;

    public Propertydetails() {
    }

    public Propertydetails(Integer propertyId) {
        this.propertyId = propertyId;
    }

    public Propertydetails(Integer propertyId, String description, double propertyPrice, String address, int yearBuilt) {
        this.propertyId = propertyId;
        this.description = description;
        this.propertyPrice = propertyPrice;
        this.address = address;
        this.yearBuilt = yearBuilt;
    }

    public Integer getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(Integer propertyId) {
        this.propertyId = propertyId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPropertyPrice() {
        return propertyPrice;
    }

    public void setPropertyPrice(double propertyPrice) {
        this.propertyPrice = propertyPrice;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getYearBuilt() {
        return yearBuilt;
    }

    public void setYearBuilt(int yearBuilt) {
        this.yearBuilt = yearBuilt;
    }

    @JsonbTransient
    public Collection<Propertyimages> getPropertyimagesCollection() {
        return propertyimagesCollection;
    }

    public void setPropertyimagesCollection(Collection<Propertyimages> propertyimagesCollection) {
        this.propertyimagesCollection = propertyimagesCollection;
    }

    @JsonbTransient
    public Collection<Transactiondetails> getTransactiondetailsCollection() {
        return transactiondetailsCollection;
    }

    public void setTransactiondetailsCollection(Collection<Transactiondetails> transactiondetailsCollection) {
        this.transactiondetailsCollection = transactiondetailsCollection;
    }

    @JsonbTransient
    public Collection<Feedbackdetails> getFeedbackdetailsCollection() {
        return feedbackdetailsCollection;
    }

    public void setFeedbackdetailsCollection(Collection<Feedbackdetails> feedbackdetailsCollection) {
        this.feedbackdetailsCollection = feedbackdetailsCollection;
    }

    public Areamaster getAreaId() {
        return areaId;
    }

    public void setAreaId(Areamaster areaId) {
        this.areaId = areaId;
    }

    public Citymaster getCityId() {
        return cityId;
    }

    public void setCityId(Citymaster cityId) {
        this.cityId = cityId;
    }

    public Statemaster getStateId() {
        return stateId;
    }

    public void setStateId(Statemaster stateId) {
        this.stateId = stateId;
    }

    public Propertytype getTypeId() {
        return typeId;
    }

    public void setTypeId(Propertytype typeId) {
        this.typeId = typeId;
    }

    public Propertystatus getStatusId() {
        return statusId;
    }

    public void setStatusId(Propertystatus statusId) {
        this.statusId = statusId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (propertyId != null ? propertyId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Propertydetails)) {
            return false;
        }
        Propertydetails other = (Propertydetails) object;
        if ((this.propertyId == null && other.propertyId != null) || (this.propertyId != null && !this.propertyId.equals(other.propertyId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Propertydetails[ propertyId=" + propertyId + " ]";
    }
    
}
