/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Collection;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author DELL
 */
@Entity
@Table(name = "propertytype")
@NamedQueries({
    @NamedQuery(name = "Propertytype.findAll", query = "SELECT p FROM Propertytype p"),
    @NamedQuery(name = "Propertytype.findByTypeId", query = "SELECT p FROM Propertytype p WHERE p.typeId = :typeId"),
    @NamedQuery(name = "Propertytype.findByTypeName", query = "SELECT p FROM Propertytype p WHERE p.typeName = :typeName")})
public class Propertytype implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "typeId")
    private Integer typeId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "typeName")
    private String typeName;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "typeId")
    private Collection<Propertydetails> propertydetailsCollection;

    public Propertytype() {
    }

    public Propertytype(Integer typeId) {
        this.typeId = typeId;
    }

    public Propertytype(Integer typeId, String typeName) {
        this.typeId = typeId;
        this.typeName = typeName;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    @JsonbTransient
    public Collection<Propertydetails> getPropertydetailsCollection() {
        return propertydetailsCollection;
    }

    public void setPropertydetailsCollection(Collection<Propertydetails> propertydetailsCollection) {
        this.propertydetailsCollection = propertydetailsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (typeId != null ? typeId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Propertytype)) {
            return false;
        }
        Propertytype other = (Propertytype) object;
        if ((this.typeId == null && other.typeId != null) || (this.typeId != null && !this.typeId.equals(other.typeId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Propertytype[ typeId=" + typeId + " ]";
    }
    
}
