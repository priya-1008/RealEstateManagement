/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/GenericResource.java to edit this template
 */
package resource;

import ejb.AdminEJBLocal;
import entity.Areamaster;
import entity.Citymaster;
import entity.Feedbackdetails;
import entity.Propertydetails;
import entity.Propertyimages;
import entity.Propertystatus;
import entity.Propertytype;
import entity.Rolemaster;
import entity.Statemaster;
import entity.Usermaster;
import java.util.Collection;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.Path;
import javax.enterprise.context.RequestScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * REST Web Service
 *
 * @author DELL
 */
@Path("admin")
@RequestScoped
public class AdminResource {

    @EJB
    AdminEJBLocal aejb;

    public AdminResource() {
    }

    //===============All State Resources=================
    @GET
    @Path("states")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Statemaster> getAllStates() {

        return aejb.getAllStates();
    }

    @POST
    @Path("addstates/{stateName}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void addStates(@PathParam("stateName") String stateName) {
        aejb.addState(stateName);
    }
    
    @DELETE
    @Path("deletestate/{stateid}")
    public void deleteState(@PathParam("stateid") int stateid) {
        aejb.deleteState(stateid);
        System.out.println("In Delete State Resource");
    }

    @PUT
    @Path("updatestate/{id}")
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateState(@PathParam("id") Integer stateId, String stateName) {
        try {
            aejb.updateState(stateId, stateName);
            return Response.ok().entity("State updated successfully").build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.NOT_FOUND).entity(e.getMessage()).build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("An error occurred").build();
        }
    }

    //=================All City Resources=================
    @GET
    @Path("cities")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Citymaster> getAllCities() {

        return aejb.getAllCities();
    }

    @POST
    @Path("addcity/{cityName}/{stateId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addCity(@PathParam("cityName") String cityName, @PathParam("stateId") Integer stateId) {
        try {
            aejb.addCity(cityName, stateId);
            return Response.status(Response.Status.CREATED).entity("City added successfully").build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Error adding city: " + e.getMessage()).build();
        }
    }
    
    @DELETE
    @Path("deletecity/{cityid}")
    public void deleteCity(@PathParam("cityid") int cityid) {
        aejb.deleteCity(cityid);
        System.out.println("In Delete City Resource");
    }

    //================All Area resources===================
    @GET
    @Path("areas")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Areamaster> getAllAreas() {
        return aejb.getAllAreas();
    }

    @POST
    @Path("addarea/{areaName}/{cityId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addArea(@PathParam("areaName") String areaName, @PathParam("cityId") Integer cityId) {
        try {
            aejb.addArea(areaName, cityId);
            return Response.status(Response.Status.CREATED).entity("Area added successfully").build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Error adding area: " + e.getMessage()).build();
        }
    }
    
    @DELETE
    @Path("deletearea/{areaid}")
    public void deleteArea(@PathParam("areaid") int areaid) {
        aejb.deleteArea(areaid);
        System.out.println("In Delete Area Resource");
    }

    //==============All Propertytype resources==================
    @GET
    @Path("types")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Propertytype> getAllTypes() {
        return aejb.getAlltypes();
    }

    //============All Propertystatus resources=================
    @GET
    @Path("status")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Propertystatus> getAllStatus() {
        return aejb.getAllStatus();
    }

    //===============ALL ROLEMASTER METHODS======================
    @GET
    @Path("roles")
    public Collection<Rolemaster> getAllRoles() {
        return aejb.getAllRoles();
    }
    
    //==============All Propertyimages resources======================
     @POST
     @Path("addimage")
    @Consumes(MediaType.APPLICATION_JSON)
    public void addImage(Propertyimages image) {
        aejb.addImage(image);
        System.out.println("Image add in resource");
    }

    @GET
    @Path("images")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Propertyimages> getAllImages() {
        return aejb.getAllImages();
    }

    //===============All Propertydetails resources==============
    @GET
    @Path("properties")
    public Collection<Propertydetails> getAllProperties() {
        return aejb.getAllProperties();
    }

    @POST
    @Path("addproperty/{typeId}/{description}/{price}/{address}/{yearBuilt}/{statusId}/{stateId}/{cityId}/{areaId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void addProperty(@PathParam("typeId") Integer typeId, @PathParam("description") String description,
            @PathParam("price") Double price, @PathParam("address") String address,
            @PathParam("yearBuilt") Integer yearBuilt, @PathParam("statusId") Integer statusId,
            @PathParam("stateId") Integer stateId,
            @PathParam("cityId") Integer cityId, @PathParam("areaId") Integer areaId) {
        System.out.println("In Property Add");
        aejb.addProperty(typeId, description, price, address, yearBuilt, statusId, stateId, cityId, areaId);
    }
    @DELETE
    @Path("deleteproperty/{propertyId}")
    public void deleteProperty(@PathParam("propertyId") Integer propertyId) {
        aejb.deleteProperty(propertyId);
        System.out.println("In resource delete property");
    }
    
    //=============ALL USERMASTER RESOURCES=================
    @GET
    @Path("users")
    public Collection<Usermaster> getAllUsers() {
        return aejb.getAllUsers();
    }
    
    @POST
    @Path("adduser/{userName}/{contactNo}/{address}/{email}/{password}/{roleId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void addUser(@PathParam("userName") String userName,@PathParam("contactNo") long contactNo,
            @PathParam("address") String address, @PathParam("email") String email,
            @PathParam("password")String password, @PathParam("roleId") Integer roleId) {
            System.out.println("In User Add");
        
            aejb.addUser(userName, contactNo, address, email, password, roleId);
    }
    
    @POST
    @Path("updateuser/{userId}/{userName}/{contactNo}/{address}/{email}/{password}/{roleId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateUser(@PathParam("userId") Integer userId,@PathParam("userName") String userName,@PathParam("contactNo") long contactNo,
            @PathParam("address") String address, @PathParam("email") String email,
            @PathParam("password")String password, @PathParam("roleId") Integer roleId) {
        
            aejb.updateUser(userId, userName, 0, address, email, password, roleId);
            System.out.println("In resource user updated");
    }
    
    //==========ALL FEEDBACKDETAILS RESOURCE================
    @GET
    @Path("feedbacks")
    public Collection<Feedbackdetails> getAllFeedbacks() {
        return aejb.getAllFeedbacks();
    }

}
