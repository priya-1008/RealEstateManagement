/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/GenericResource.java to edit this template
 */
package resource;

import ejb.UserEJBLocal;
import entity.Propertydetails;
import java.util.Collection;
import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.enterprise.context.RequestScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author DELL
 */
@Path("user")
@RequestScoped
public class UserResource {

    @EJB
    UserEJBLocal aejb;
    
    @GET
    @Path("properties")
    public Collection<Propertydetails> getAllProperties() {
        return aejb.getAllProperties();
    }
    
    @POST
    @Path("addfeedback/{description}/{propertyId}/{userId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void addFeedback(@PathParam("description") String description,
            @PathParam("propertyId") Integer propertyId, @PathParam("userId") Integer userId) {
        
        aejb.addFeedback(description, propertyId, userId);
        System.out.println("In Feedback Add resource");
    }
}
